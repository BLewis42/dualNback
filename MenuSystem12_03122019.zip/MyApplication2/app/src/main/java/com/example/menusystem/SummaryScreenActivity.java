package com.example.menusystem;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class SummaryScreenActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary_screen);
    }
}
