package com.example.menusystem;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainScreen extends AppCompatActivity
{

    private Button selectUserLogin;
    private Button selectAdminLogin;
    private Button selectWelcomeLogin;
    private Button selectQuitApp;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main_screen);

        selectUserLogin = (Button) findViewById(R.id.selectUserLogin);
        selectAdminLogin = (Button) findViewById(R.id.selectUserLogin);
        selectWelcomeLogin = (Button) findViewById(R.id.selectWelcomeScreen);
        selectQuitApp = (Button) findViewById(R.id.selectQuitApp);

        selectUserLogin.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                openActivityUserLogin();
            }
        });

        selectAdminLogin.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v) {
                openActivityAdminLogin();
            }
        });

        selectWelcomeLogin.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v) {
                openActivityWelcomeScreen();
            }
        });

        selectQuitApp.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v) {
                openActivityQuitApp();
            }
        });
    }

    public void openActivityUserLogin()
    {
        Intent intent = new Intent(this, UserLoginActivity.class);
        startActivity(intent);
    }

    public void openActivityAdminLogin()
    {
        Intent intent = new Intent(this, AdminLoginActivity.class);
        startActivity(intent);
    }

    public void openActivityWelcomeScreen()
    {
        Intent intent = new Intent(this, WelcomeScreen.class);
        startActivity(intent);
    }

    public void openActivityQuitApp()
    {
        finishAffinity();
    }

}



