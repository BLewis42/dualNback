package com.example.menusystem;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class WelcomeScreen extends AppCompatActivity {

    private Button welcomeNext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        welcomeNext = (Button) findViewById(R.id.welcomeNext);

        welcomeNext.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                openActivityMainScreen();
            }
        });
    }

        public void openActivityMainScreen()
        {
            Intent intent = new Intent(this, MainScreen.class);
            startActivity(intent);
        }
    }



