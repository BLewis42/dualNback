package com.example.menusystem;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class oneBackTutorial extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_one_back_tutorial);
    }
}
