package com.example.menusystem;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class CreateUserAccount extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_user_account);
    }
}
